#pragma once
#include <cstdbool>
#include <cstdlib>
#include <cstdio>
#include "ofMain.h"
#include <iostream>
#include <stack>
#include <fstream>
using namespace std;

class ofApp : public ofBaseApp{

	public:
		void setup();
		void update();
		void draw();

		void keyPressed(int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void mouseEntered(int x, int y);
		void mouseExited(int x, int y);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);
		bool processFile(ofFileDialogResult openFileResult);
		ofFileDialogResult fileresult;
		int** Maze; // Space-Efficient than struct array form.
		int SIZE;
		void getPath(int startX, int startY, int destX, int destY);
		bool** Visited;
		stack <int> CoorX;
		stack <int> CoorY;
		bool checkToMove(int curY, int curX);
		void getShortestPath();
		bool checkStack(int i, int j);
		ofEasyCam cam;

		int startX, startY;
		int destX, destY;

		typedef struct _FinCoor {
			int xCoor;
			int yCoor;
		}FinCoor;

		FinCoor* stackDatas;
		int ShortPathNum;

};
