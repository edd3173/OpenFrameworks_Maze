#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
	ofSetBackgroundColor(255, 255, 204); // background light yellow
	processFile(fileresult); // process files at first
	cam.setDistance(200); // setup camera settings

	startX = 1;
	startY = 1;

	destX = SIZE - 2;
	destY = SIZE - 2; // initialization.

	cout << "input start loc > ";
	cin >> startY >> startX;
	
	if (startX >= SIZE || startY >= SIZE || startX<0 || startY <0) {
		cout << "Start Location Out Of Range!" << endl;
		ofExit(); // out of range, exit program
	}

	cout << "input dest loc > ";
	cin >> destY >> destX;
	
	if (destX >= SIZE || destY >= SIZE || destX<0 || destY<0) {
		cout << "Destination Location Out Of Range!" << endl;
		ofExit(); // out of range, exit program
	}

	// user-selectable start Loc and dest Loc

	getPath(startX, startY, destX, destY);
	// Solve the maze using DFS

	getShortestPath();
	// get shortest path
}

//--------------------------------------------------------------
void ofApp::update(){

}

//--------------------------------------------------------------
void ofApp::draw(){
	cam.begin(); // camera setup


	/* VISUALIZING MAZE IN 3D */
	int x = 10; int y = 10; int z = 0;
	for (int i = 0; i < SIZE; i++) {
		for (int j = 0; j < SIZE; j++) {
			if (Maze[i][j] == 1) { // If it is a WALL
				ofSetColor(51, 51, 51); // Grayish Black
				ofDrawBox(x, y, z, 20); // Draw Box
			}
			if (Maze[i][j] == 0) { // If it is a WAY
				ofSetColor(153, 255, 153); // LightGreen 
				ofDrawBox(x, y, z, 20); // Draw Box
				if (checkStack(j, i) == true) { // If Box belongs to ShortestPath
					ofSetColor(255, 153, 255); // LightPink
					ofDrawBox(x, y, z, 5); // Show Shortest Track
				}
			}
			x += 20; // move  X cursor to draw next block
		}
		x = 10; // col index initialization
		y+=20; // move Y cursor to draw next line
	}
	
	cam.end(); 
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
	if (key == 'q') { // free allocated memory and exit program

		for (int i = 0; i < SIZE; i++)
			delete[] Maze[i];
		delete[] Maze; // free Maze

		for (int i = 0; i < SIZE; i++)
			delete[] Visited[i];
		delete[] Visited; // free Visited

		delete[] stackDatas; // free StackDatas

		ofExit(); // exit Program
	}
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}

bool ofApp::processFile(ofFileDialogResult openFileResult) {
	openFileResult = ofSystemLoadDialog();
	if (openFileResult.bSuccess)
	{
		ofBuffer buf = ofBufferFromFile(openFileResult.getPath());
		ofFile file(openFileResult.getPath());

		file >> SIZE;
		//cout << "maze's size is : " << SIZE << endl;

		Maze = new int*[SIZE];
		for (int i = 0; i < SIZE; i++)
			Maze[i] = new int[SIZE]; // dynamic mem alloc for maze

		for (int i = 0; i < SIZE; i++) {
			for (int j = 0; j < SIZE; j++)
				file >> Maze[i][j];
		} // get maze data

		Visited = new bool*[SIZE];
		for (int i = 0; i < SIZE; i++)
			Visited[i] = new bool[SIZE]; // dynamic mem alloc for Visited.

		for (int i = 0; i < SIZE; i++) {
			for (int j = 0; j < SIZE; j++)
				Visited[i][j] = 0; // Init. to make no visit so far.
		}

		stackDatas = new FinCoor[SIZE*SIZE];
		for (int i = 0; i < SIZE*SIZE; i++) {
			stackDatas[i].xCoor = -1;
			stackDatas[i].yCoor = -1;
		} // to track ShortestPath datas in Stack

		
		for (int i = 0; i < SIZE; i++) {
			for (int j = 0; j < SIZE; j++)
				cout << Maze[i][j];
			cout << endl;
		} // File Input Check.

	}
	else
		return false;
}

bool ofApp::checkToMove(int curY, int curX) {
	if (curY == 0 || curY == SIZE - 1 || curX == 0 || curX == SIZE - 1 || Visited[curY][curX] || Maze[curY][curX] == 1)
		return false; // dead end
	else
		return true; // able to go further
}

void ofApp::getShortestPath() {
	ShortPathNum = 0; // number of stacks datas, containing Shortest Paths
	while (!CoorX.empty() && !CoorY.empty()) {
		int xCoor = CoorX.top();
		int yCoor = CoorY.top();

		//printf(" (%d,%d)\n", yCoor, xCoor);
		stackDatas[ShortPathNum].xCoor = xCoor;
		stackDatas[ShortPathNum].yCoor = yCoor;
		// Input ShortestPath Datas in StackDats

		CoorX.pop();
		CoorY.pop(); // Pop.
		ShortPathNum++; // index++
	}
	return;
}


void ofApp::getPath(int startX, int startY, int destX, int destY) {
	int curX = startX;
	int curY = startY;
	int dir;
	if (Maze[startY][startX] == 1 || Maze[destY][destX] == 1) {
		cout << "Wrong input Loc! Do it Again!" << endl;
		ofExit();
	} // inside Maze, but invalid input because of Wall Existence


	CoorX.push(startX);
	CoorY.push(startY);
	Visited[startY][startX] = true;
	// check

	while (!CoorX.empty() && !CoorY.empty()) {
		int topX = CoorX.top();
		int topY = CoorY.top();
		//printf("top Coor : (%d,%d)\n", topY, topX);


		if (topX == destX && topY == destY) {
			cout << "Found the Path" << endl;
			return; // success
		}

		// up
		if (checkToMove(topY - 1, topX)) {
			CoorX.push(topX);
			CoorY.push(topY - 1);
			Visited[topY - 1][topX] = true;
		}

		// down
		else if (checkToMove(topY + 1, topX)) {
			CoorX.push(topX);
			CoorY.push(topY + 1);
			Visited[topY + 1][topX] = true;
		}

		//left
		else if (checkToMove(topY, topX - 1)) {
			CoorX.push(topX - 1);
			CoorY.push(topY);
			Visited[topY][topX - 1] = true;
		}

		//right
		else if (checkToMove(topY, topX + 1)) {
			CoorX.push(topX + 1);
			CoorY.push(topY);
			Visited[topY][topX + 1] = true;
		}

		// dead end
		else {
			CoorX.pop();
			CoorY.pop();
		} // pop and go back
	}
}

bool ofApp::checkStack(int i, int j) { // check current element
	for (int k = 0; k < ShortPathNum; k++) {
		if (stackDatas[k].xCoor == i && stackDatas[k].yCoor == j)
			return true;
		// current Maze[i][j] belongs to ShortestPath Datas
	}
	return false;
}